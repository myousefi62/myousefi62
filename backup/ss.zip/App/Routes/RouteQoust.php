<?php
use Slim\Http\Request;
use Slim\Http\Response;
// ثبت نام کاربر جدید
$app->post('/user/reg', function (Request $request, Response $response, array $args) {
    $UserName = $request->getParsedBodyParam('UserName', $default = null);
    $Password = $request->getParsedBodyParam('Password', $default = null);
    $Mobile = $request->getParsedBodyParam('Mobile', $default = null);
    $RefrencsID = $request->getParsedBodyParam('RefrencsID', $default = 1);

    //$result = array() ; 
   
    if (isset($UserName)&&isset($Password)&&isset($Mobile))
    {
        //echo count(ValidPassword($Password));
        // print_r(ValidPassword($Password));
        // echo  ValidMobile($Mobile);
        $newResponse;
        $dbhandler = $this->get("dbh");
        $errorPassword = ValidPassword($Password);
        $errorUser = ValidUser($UserName , $Mobile,$dbhandler);
        // print_r($errorPassword);
        // print_r($errorUser);
        if (ValidText($UserName)&& count($errorPassword) == 0  && ValidMobile($Mobile)&& count($errorUser) == 0 )
            {
                $pdo = $this->get("dbh");
                $pdo->beginTransaction();
    
                //این عملیات با ترنز اکشن انجام خواهد شد و در صورتی که هر مرحله با خطایی مواجه گردید عملیات رول بک انجام خواهد شد
                //That way, we can rollback the transaction if a query fails and a PDO exception occurs.
                try{
                    // بدست اوردن ip کاربر
                    $IP = GetClientIP();
                    // رمز نگاری رمز عبور کاربر
                    $Password = HashPass($UserName,$UserPassword);
                    // نام نویسی کاربر جدید
                    $stmt = $pdo->prepare	("INSERT INTO tbuser 
                                                        (`UserName`, `Password`, `RefrencsID`, `IP`, `Mobile`)
                                                    VALUES 
                                                        (:UserName, :Password, :RefrencsID, :IP, :Mobile)");
                    $stmt->bindParam(':UserName' 		,$UserName);
                    $stmt->bindParam(':Password' 		,$Password);
                    $stmt->bindParam(':RefrencsID' 	    ,$UserPassword);
                    $stmt->bindParam(':IP'          	,$IP);
                    $stmt->bindParam(':Mobile'	        ,$Mobile);
                    
                    $stmt->execute();		
                    // شناسه کاربر جدید را بدست می اوریم
                    $stmtUserID = $pdo->prepare("SELECT UserID  FROM tbuser where UserName = '$UserName' and Password = '$Password'"); 

                    $stmtUserID->execute(); 
                    $row = $stmtUserID->fetch();
                
                    $UserID = $row ["UserID"];
                    
                    //echo $UserID ;
                    date_default_timezone_set('UTC');
                    // مدت اعتبار توکن ایجاد شده برابر با دو ماه می باشد
                    $timestamp=strtotime("+60 Days");
                    $DateExpire =  date('Y-m-d H:i:s', $timestamp);
                    $token = getToken(50);
                    // کاربر جدید به سیستم لاگین می کند
                    $stmtlogin = $pdo->prepare("INSERT INTO tblogin
                                (UserID, Token, IP,DateExpire) 
                            VALUES 
                                (:UserID,:token,:IP,:DateExpire)");
                    $stmtlogin->bindParam(':UserID'	,$UserID);
                    $stmtlogin->bindParam(':token'	,$token);
                    $stmtlogin->bindParam(':IP'		,$IP);
                    $stmtlogin->bindParam(':DateExpire'	,$DateExpire);
                    $stmtlogin->execute();
                    
                    $result['token'] =$token  ;
                                    
                    //در صورتی که هیچ خطایی اتفاق نیوفتاد تغییرات کامیت می شود
                    $pdo->commit();
                    // خروجی این ای پی ای با ساختار از پیش تعیین شده به سمت کلاینت ارسال خواهید شد 
                    $newResponse = $response->withStatus(200)->withJson(ApiResult($result,null,null));
                    
                } 
                //در صورت بروز خطا
                catch(Exception $e){
                    $pdo->rollBack();
                    $error['regerror']='خطا در مراحل ثبت نام لطفا بعدا تلاش نمایید';
                $newResponse = $response->withStatus(401)->withJson($error);
                }
            }
            else {
                $error ;
                if (!ValidText($UserName))
                    $error['ValidText']='نام کاربر معتبر نمی باشد';
                if (count($errorPassword) != 0  )
                    $error['errorPassword']=$errorPassword;
                if (!ValidMobile($Mobile))
                    $error['ValidMobile'] = 'شماره موبایل معتبر نمی باشد';
                if (count($errorUser) != 0 )
                    $error['errorUser']=$errorUser;
                $newResponse = $response->withStatus(401)->withJson(ApiResult(null,$error,null));
            }
            //     echo $token = getToken(50);
            // $UserIP = GetClientIP();
            // echo $UserIP;
    }else{
        $newResponse = $response->withStatus(400)->withJson($request->getHeader(null));
    }

//print_r($request);
//print_r($request->getUri()->getPath());
//print_r($response);
// print_r($request->getHeaders());
//print_r($request->getParsedBody() );
    
       return $newResponse;
});
// ورود کاربر به سیستم
$app->post('/user/login', function (Request $request, Response $response, array $args){
    $UserName = $request->getParsedBodyParam('UserName', $default = null);
    $Mobile = $request->getParsedBodyParam('Mobile', $default = null);
    $Email = $request->getParsedBodyParam('Email', $default = null);
    $Password = $request->getParsedBodyParam('Password', $default = null);
    $pdo = $this->get("dbh");
    if(!isset($UserName) &&((isset($Mobile)||isset($Email)))){
        $stmt = $pdo->prepare("SELECT UserName  FROM tbuser where Email = '$Email' or Mobile = '$Mobile' "); 
        $stmt->execute(); 
        $row = $stmt->fetch();
        $UserName = $row ["UserName"];
    }
    if(isset($UserName) && isset($Password)){
        $Password = HashPass($UserName,$UserPassword);

        $stmt = $pdo->prepare("SELECT count(*) count , UserID  FROM tbuser where Username = '$UserName' and Password = '$Password'"); 
        $stmt->execute(); 
        $row = $stmt->fetch();
        $count = $row ["count"]; 
        $UserID = $row ["UserID"]; 
        //echo $count;
        if (intval($count) == 1 )	
        {
            date_default_timezone_set('UTC');
            // مدت اعتبار توکن ایجاد شده برابر با دو ماه می باشد
            $timestamp=strtotime("+60 Days");
            $DateExpire =  date('Y-m-d H:i:s', $timestamp);
            $token = getToken(50);
            $IP = GetClientIP();
            // کاربر جدید به سیستم لاگین می کند
            $stmtlogin = $pdo->prepare("INSERT INTO tblogin
                        (UserID, Token, IP,DateExpire) 
                    VALUES 
                        (:UserID,:token,:IP,:DateExpire)");
            $stmtlogin->bindParam(':UserID'	,$UserID);
            $stmtlogin->bindParam(':token'	,$token);
            $stmtlogin->bindParam(':IP'		,$IP);
            $stmtlogin->bindParam(':DateExpire'	,$DateExpire);
            $stmtlogin->execute();
            
            $result['token'] =$token  ;
            echo token;
            $newResponse = $response->withStatus(200)->withJson(ApiResult($result,null,null));
        }
        else{  
        $message['Usernotfound']='کاربر مورد نظر یافت نشد';	
        $newResponse = $response->withStatus(400)->withJson(ApiResult(null,$message,null));	
    }
    }else{
        $message= array();
        if(!isset($UserName)){
            $message['UsernameError']='نام کاربری ,شماره همراه,پست الکترونیکی را وارد کنید';
        }
        if(!isset($Password)){
            $message['password'] = 'رمز عبور را وارد کنید';
        }
        $newResponse = $response->withStatus(400)->withJson(ApiResult(null,$message,null));	
    }

    return $newResponse;
});